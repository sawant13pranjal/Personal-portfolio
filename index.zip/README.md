# Tasks
I made portfolio &amp; replica of Netflix website
